<div class="left-sidebar bg-black-300 box-shadow ">
    <div class="sidebar-content">

        <!-- /.user-info -->


        <div class="sidebar-nav">
            <ul class="side-nav color-gray">

                <li>
                    <a href="teacher-dashboard.php"><i class="fa fa-wrench"></i> <span>Dashboard</span> </a>

                </li>

                <li class="">
                    <a href="#"><i class="fa fa-info-circle"></i> <span>Result</span>
                    </a>
                    <ul class="child-nav">
                        <li><a href="add-result-teacher.php"><i class="fa fa-bars"></i> <span>Add Result</span></a></li>
                        <li><a href="manage-result-teacher.php"><i class="fa fa fa-server"></i> <span>Manage
                                    Result</span></a>
                        </li>

                    </ul>
                </li>


            </ul>
            </li>










        </div>
        <!-- /.sidebar-nav -->
    </div>
    <!-- /.sidebar-content -->
</div>